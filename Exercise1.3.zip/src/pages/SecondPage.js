import '@mui/material';
import React from 'react';


function SecondPage() {
  return (
    <div className="App">
      <header className="App-header">
        <p>This is the assigment 1.3</p>
        <h2>This page contains links for exercise!</h2>

      </header>

    </div>
  );
}

export default SecondPage;