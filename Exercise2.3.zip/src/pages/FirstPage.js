import '@mui/material';
import React from 'react';

const FirstPage = () => {
  return (
    <div>
      <header className="App-header">
        <h1>
          This is the first page
        </h1>
      <p>Wanted to try difference between const and function</p>
      </header>

    </div>
  );
};

export default FirstPage;