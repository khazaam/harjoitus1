#Uni project - for class, contains some things for React UI Class
