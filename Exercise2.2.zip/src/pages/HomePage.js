import React from "react";
import '@mui/material';

const Home = () => {
    return (
        <div>
            <h1>This is the homepage</h1>
        </div>
    );
};

export default Home;