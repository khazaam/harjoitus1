import '@mui/material';
import { Button } from '@mui/material';
import React from 'react';


function ThirdPage() {
  return (
    <div className="App">
      <header className="App-header">
        <p>This is the assigment 1.3</p>
        <h2>This page contains links for exercise!</h2>
        <div>
          <Button variant="outlined">Third page</Button>
        </div>
      </header>

    </div>
  );
}

export default ThirdPage;